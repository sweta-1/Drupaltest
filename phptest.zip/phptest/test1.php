<?php
    /*Swap start*/

    $a = 20;
    $b = 40;

    $a = $a+$b;
    //echo $a;

    $b = $a-$b;
    echo "value of b is:" ."".$b.'<br>.';

    $a =$a-$b;
    echo "value of a is:" ."".$a;


    /*Swap end*/

?>