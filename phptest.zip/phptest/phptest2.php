

<?php

/* overriding example*/
class base{

    public $var1='test';
    public function show(){
     echo 'hii';

    }
}


class  derive extends base{
    public $var1='example';
    public function show(){
     echo 'hello';

    }

}

$obj2 = new derive();
echo $obj2->show();

echo $obj2->var1;



?>